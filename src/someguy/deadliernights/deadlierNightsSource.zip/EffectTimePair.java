package someguy.deadliernights;

import org.bukkit.potion.PotionEffectType;

public class EffectTimePair
{
	private int delay;
	private PotionEffectType effect;
	private int level;
	private String text;
	
	EffectTimePair(int delay, PotionEffectType effect, int level, String text)
	{
		this.delay=delay;
		this.effect=effect;
		this.level=level;
		this.text=text;
	}
	
	public int getDelay()
	{
		return delay;
	}
	
	public PotionEffectType getEffect()
	{
		return effect;
	}
	
	public int getLevel()
	{
		return level;
	}
	
	public String getText()
	{
		return text;
	}
}
