package someguy.deadliernights;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

import org.bukkit.GameMode;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerGameModeChangeEvent;
import org.bukkit.event.player.PlayerLoginEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;

public class DeadlierNights extends JavaPlugin implements Listener
{
	private boolean chat;
	private boolean log;
	private int shortestDelay;
	private ArrayList<EffectTimePair> effects;
	HashMap<String, Integer> playerMap;

	public void onEnable()
	{
		loadSettings();
		shortestDelay = getShortestDelay();
		playerMap = new HashMap<String, Integer>();
		getServer().getPluginManager().registerEvents(this, this);
		for (Player player : getServer().getOnlinePlayers())
		{
			playerMap.put(player.getName(), 0);
		}

		@SuppressWarnings("unused")
		BukkitTask checker = new PlayerCheckTask(this).runTaskTimer(this, 0, 20L);

		chat = true;
		log = true;
	}

	public void onDisable()
	{

	}

	public void checkPlayers()
	{
		for (Player player : getServer().getOnlinePlayers())
		{
			if (!playerMap.containsKey(player.getName()))
			{
				getLogger().info(player.getName() + " logged in and was added to the list of death");
				playerMap.put(player.getName(), 0);
			}

			if (player.getLocation().getBlock().getLightFromBlocks() == 0 && getServer().getWorld(player.getWorld().getName()).getTime() % 24000 >= 14000 && !(player.getGameMode().equals(GameMode.CREATIVE)))
			{
				playerMap.put(player.getName(), playerMap.get(player.getName()) + 1);
				int current = playerMap.get(player.getName());

				for (EffectTimePair pair : effects)
				{

					if (pair.getDelay() > current)
					{
						if (!player.hasPotionEffect(pair.getEffect()))
						{
							player.addPotionEffect(new PotionEffect(pair.getEffect(), Integer.MAX_VALUE, pair.getLevel()));
							if (log)
								getLogger().info("Applied " + pair.getEffect().getName() + " " + pair.getLevel() + " to " + player.getName());
						}
					}
					else if (pair.getDelay() == current)
					{
						player.addPotionEffect(new PotionEffect(pair.getEffect(), Integer.MAX_VALUE, pair.getLevel()));
						if (log)
							getLogger().info("Applied " + pair.getEffect().getName() + " " + pair.getLevel() + " to " + player.getName());
						if (chat)
							player.sendMessage(pair.getText());
					}
				}
			} else if (playerMap.get(player.getName()) > 0)
			{
				if (playerMap.get(player.getName()) >= shortestDelay)
				{
					if (log)
						getLogger().info("Debuffs removed from " + player.getName());
					if (chat)
						player.sendMessage("You escape from the darkness.");
					for (EffectTimePair pair : effects)
					{
						player.removePotionEffect(pair.getEffect());
					}
				}
				playerMap.put(player.getName(), 0);
			}
		}
	}

	public void onPlayerLogin(PlayerLoginEvent event)
	{

	}

	public void onGamemodeChange(PlayerGameModeChangeEvent event)
	{
		if (playerMap.containsKey(event.getPlayer().getName()))
		{
			playerMap.put(event.getPlayer().getName(), 0);
		}
	}

	public void onPlayerRespawn(PlayerRespawnEvent event)
	{
		playerMap.put(event.getPlayer().getName(), 0);
	}

	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args)
	{
		if (cmd.getName().equals("DNchat"))
		{
			if (args.length == 0)
			{
				if (chat == true)
					sender.sendMessage("[DeadlierNights]: Chat messages are enabled");
				else if (chat == false)
					sender.sendMessage("[DeadlierNights]: Chat messages are disabled");
			}
			if (args[0].equalsIgnoreCase("true"))
			{
				chat = true;
				sender.sendMessage("[DarkNights]: Chat messages enabled.");
				return true;
			} else if (args[0].equalsIgnoreCase("false"))
			{
				chat = false;
				sender.sendMessage("[DarkNights]: Chat messages disabled.");
				return true;
			} else
			{
				return false;
			}
		} else if (cmd.getName().equals("DNlog"))
		{
			if (args.length == 0)
			{
				if (chat == true)
					sender.sendMessage("[DeadlierNights]: Log messages are enabled");
				else if (chat == false)
					sender.sendMessage("[DeadlierNights]: Log messages are disabled");
			}
			if (args[0].equalsIgnoreCase("true"))
			{
				log = true;
				sender.sendMessage("[DarkNights]: Log messages enabled.");
				return true;
			} else if (args[0].equalsIgnoreCase("false"))
			{
				log = false;
				sender.sendMessage("[DarkNights]: Log messages disabled.");
				return true;
			} else
			{
				return false;
			}
		} else
			return false;

	}

	public void loadSettings()
	{
		effects = new ArrayList<EffectTimePair>();
		Scanner scanner;
		int line = 0;
		try
		{
			scanner = new Scanner(new File("plugins\\DeadlierNights\\effects.txt"));
			try
			{
				String input = "";
				while (scanner.hasNext())
				{
					boolean done = false;
					int newDelay = -1;
					PotionEffectType newEffect = null;
					int newLevel = 0;
					String newText = "";
					while (!done)
					{
						line++;
						input = scanner.nextLine();
						if (input.contains("delay:"))
						{
							newDelay = Integer.parseInt(input.replaceAll("delay:", ""));
							System.out.println(newDelay);
						}
						if (input.contains("effect:"))
						{
							newEffect = PotionEffectType.getByName(input.replaceAll("effect:", ""));
							System.out.println(input.replaceAll("effect:", ""));
							System.out.println(newEffect);
						}
						if (input.contains("level:"))
						{
							newLevel = Integer.parseInt(input.replaceAll("level:", ""));
							System.out.println(newLevel);
						}
						if (input.contains("text:"))
						{
							newText = input.replaceAll("text:", "");
						}
						if (input.contains("---"))
						{
							System.out.println("trying to complete");
							done = true;
							System.out.println(newDelay == -1);
							System.out.println(newEffect == null);
							if (newDelay == -1 || newEffect == null)
								throw new IOException("Error: delay or effect is missing from an effects entry on line " + line);
							else if (newDelay <= 0)
								throw new IOException("Error: delay must have a value greater than zero on line " + line);
							effects.add(new EffectTimePair(newDelay, newEffect, newLevel, newText));
							System.out.println(effects);
						}
					}
				}
			} catch (NumberFormatException e)
			{
				System.out.println(e);
				getLogger().warning("ERROR: Can't read effects.txt (is there a typo on line " + line + "?)");
			} catch (IOException e)
			{
				System.out.println(e);
				getLogger().warning("ERROR: Can't read effects.txt (is there a typo on line " + line + "?)");
			} finally
			{
				scanner.close();
			}
		} catch (FileNotFoundException e)
		{
			try
			{
				getLogger().info(new java.io.File(".").getCanonicalPath());
			} catch (IOException e1)
			{
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			try
			{
				(new File("plugins\\DeadlierNights")).mkdirs();
				(new File("plugins\\DeadlierNights\\effects.txt")).createNewFile();
			} catch (IOException ee)
			{
				getLogger().warning(ee.getMessage());
			}
		}
	}

	private int getShortestDelay()
	{
		int shortest = Integer.MAX_VALUE;

		for (EffectTimePair pair : effects)
		{
			if (pair.getDelay() < shortest)
				shortest = pair.getDelay();
		}

		return shortest;
	}
}